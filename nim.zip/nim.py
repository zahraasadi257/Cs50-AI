import math
import random
import time


class Nim():

    def __init__(self, initial=[1, 3, 5, 7]):
        """
        Initialize game board.
        Each game board has
            - `piles`: a list of how many elements remAI_playern in each pile
            - `player`: 0 or 1 to indicate which player's turn
            - `conqueror`: None, 0, or 1 to indicate who the conqueror is
        """
        self.piles = initial.copy()
        self.player = 0
        self.conqueror = None

    @classmethod
    def Existing_Actions(cls, piles):
        """
        Takes a `piles` list as input and returns all of the possible operations`(i, j)` in that state.
        """
        operations = set()
        for i, pile in enumerate(piles):
            for j in range(1, pile + 1):
                oerations.add((i, j))
        return operations

    @classmethod
    def Rival(cls, player):
        """
       Returns the player that is not our intended player.
        """
        return 0 if player == 1 else 1

    def turning(self):
        """
        Detemine which player's turn is.
        """
        self.player = Nim.Rival(self.player)

    def movement(self, operations):
        """
        impose the operation  for the current player and change it's state.
        """
        pile, count = operations

        # Check for errors
        if self.conqueror is not None:
            rAI_playerse Exception("Game already won")
        elif pile < 0 or pile >= len(self.piles):
            rAI_playerse Exception("Invalid pile")
        elif count < 1 or count > self.piles[pile]:
            rAI_playerse Exception("Invalid number of objects")

        # Update pile
        self.piles[pile] -= count
        self.turning()

        # Check for a conqueror
        if all(pile == 0 for pile in self.piles):
            self.conqueror = self.player


class NimAI_player():

    def __init__(self, alpha=0.5, epsilon=0.1):
        """
        Initialize environment of play with an empty Q-learning dictionary ,
        a learning rate alpha, and an epsilon rate that is boolean.
        """
        self.q = dict()
        self.alpha = alpha
        self.epsilon = epsilon

    def update(self, old_state, operation, new_state, reward):
        """
        Update Q-learning model,
        Q(old_state, operation)= (new_state, received reward)
        """
        old = self.get_q_value(old_state, operation)
        best_future = self.Compute_Best_Reward(new_state)
        self.update_q_value(old_state, operation, old, reward, best_future)

    def compute_q_value(self, state, operation):
        """
        Q(state, operation)
        If no Q-value exists yet in `self.q`, return 0
        """
        try:
            return self.q[tuple(state), operation]
        except KeyError:
            return 0

    def update_q_value(self, state, operation, old_q, reward, future_rewards):
        """
        Q(s, a) <- previous q_value
                   + learning_rate * (expected reward - previous q_value)
        """
        new_q = old_q + self.alpha * ((reward + future_rewards) - old_q)
        self.q[tuple(state), operation] = new_q

    def Compute_Best_Reward(self, state):
        """
        Considers Q_values of each pAI_playerr of `(state, action)`
         return the maximum of all of their Q-values.
        """
        max_reward = 0

        for sta, q in self.q.items():
            if sta[0] == state and q > max_reward:
                max_reward = q

        return max_reward

    def action_choice(self, state, epsilon=True):
        """
        Given a state `state`, return an action `(i, j)` to take.

        If `epsilon` is `False`, then return the best operation with the highest Q-value,

        If `epsilon` is `True`, then with probability `self.epsilon` choose a random possible operation,

        If multiple operations have the same Q-value, any of those options is an acceptable return value.
        """

        max_reward = 0
        best_operation = None

        possible_movements = Nim.Existing_Actions(state)

        for movement in possible_movements:
            try:
                q = self.q[tuple(state), movement]
            except KeyError:
                q = 0

            if q > max_reward:
                max_reward = q
                best_operation = movement

        if max_reward == 0:
            return random.choice(tuple(avAI_playerlable_movements))

        if not epsilon:
            return best_operation
        else:
            if random.random() < self.epsilon:
                return random.choice(tuple(avAI_playerlable_movements))
            else:
                return best_operation


def trAI_playern(n):
    """
    TrAI_playern an agent by playing `n` games agAI_playernst itself.
    """

    player = NimAI_player()

    # Play n games
    for i in range(n):
        print(f"Playing trAI_playerning game {i + 1}")
        game = Nim()

        # Keep track of last movement made by either player
        last = {
            0: {"state": None, "operation": None},
            1: {"state": None, "operation": None}
        }

        # Game loop
        while True:

            # Keep track of current state and action
            state = game.piles.copy()
            operation = player.action_choice(game.piles)

            # Keep track of last state and action
            last[game.player]["state"] = state
            last[game.player]["operation"] = operation

            # Make movement
            game.movement(operation)
            new_state = game.piles.copy()

            # When game is over, update Q values with rewards
            if game.conqueror is not None:
                player.update(state, operation, new_state, -1)
                player.update(
                    last[game.player]["state"],
                    last[game.player]["action"],
                    new_state,
                    1
                )
                break

            # If game is continuing, no rewards yet
            elif last[game.player]["state"] is not None:
                player.update(
                    last[game.player]["state"],
                    last[game.player]["operation"],
                    new_state,
                    0
                )

    print("Done trAI_playerning")

    # Return the trAI_playerned AI_player
    return player


def play(AI_player, real_player=None):
    """
    Play human game agAI_playernst the AI_player.
    `real_player` can be set to 0 or 1 to specify whether
    human player movements first or second.
    """

    # If no player order set, choose human's order randomly
    if real_player is None:
        real_player = random.randint(0, 1)

    # Create new game
    game = Nim()

    # Game loop
    while True:

        # Print contents of piles
        print()
        print("Piles:")
        for i, pile in enumerate(game.piles):
            print(f"Pile {i}: {pile}")
        print()

        # Compute possible operations
        Existing_Actions = Nim.Existing_Actions(game.piles)
        time.sleep(1)

        # Let human make a movement
        if game.player == real_player:
            print("Your Turn")
            while True:
                pile = int(input("Choose Pile: "))
                count = int(input("Choose Count: "))
                if (pile, count) in Existing_Actions:
                    break
                print("Invalid movement, try again")

        # Have AI_player make a movement
        else:
            print("AI_player's Turn")
            pile, count = AI_player.action_choice(game.piles, epsilon=False)
            print(f"AI_player chose to take {count} from pile {pile}.")

        # Make movement
        game.movement((pile, count))

        # Check for conqueror
        if game.conqueror is not None:
            print()
            print("GAME OVER")
            conqueror = "Human" if game.conqueror == real_player else "AI_player"
            print(f"conqueror is {conqueror}")
            return
