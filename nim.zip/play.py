from nim import *

AI = train(10000)
play(AI)
