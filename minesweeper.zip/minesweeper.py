import itertools
import copy
import random

class Minesweeper():
    """
    Representation of  Minesweeper game
    """

    def __init__(self, GAME_Height=8, GAME_Width=8, mines=8):

        # Set initial GAME_Width, GAME_Height, and number of mines
        self.GAME_Height = GAME_Height
        self.GAME_Width = GAME_Width
        self.mines = set()

        # Initialize an empty field with no mines
        self.board = []
        for i in range(self.GAME_Height):
            row = []
            for j in range(self.GAME_Width):
                row.append(False)
            self.board.append(row)

        # Add mines randomly
        while len(self.mines) != mines:
            i = random.randrange(GAME_Height)
            j = random.randrange(GAME_Width)
            if not self.board[i][j]:
                self.mines.add((i, j))
                self.board[i][j] = True

        # At first, player has found no mines
        self.mines_found = set()

    def print(self):
        """
        Prints a text-based representation
        of where mines are located.
        """
        for i in range(self.GAME_Height):
            print("--" * self.GAME_Width + "-")
            for j in range(self.GAME_Width):
                if self.board[i][j]:
                    print("|X", end="")
                else:
                    print("| ", end="")
            print("|")
        print("--" * self.GAME_Width + "-")

    def is_mine(self, cell):
        i, j = cell
        return self.board[i][j]

    def nearby_mines(self, cell):
        """
        Returns the number of mines that are
        within one row and column of a given cell,
        not including the cell itself.
        """

        # Keep count of nearby mines
        count = 0

        # Loop over all collection_of_cells within one row and column
        for i in range(cell[0] - 1, cell[0] + 2):
            for j in range(cell[1] - 1, cell[1] + 2):

                # Ignore the cell itself
                if (i, j) == cell:
                    continue

                # Update count if cell in bounds and is mine
                if 0 <= i < self.GAME_Height and 0 <= j < self.GAME_Width:
                    if self.board[i][j]:
                        count += 1

        return count

    def won(self):
        """
        checks if all mines have been flagged.
        """
        return self.mines_found == self.mines


class Speech():
    """
    Logical statement about a Minesweeper game
    A Speech consists of a set of board collection_of_cells,
    and a count of the number of those collection_of_cells which are mines.
    """

    def __init__(self, collection_of_cells, count):
        self.collection_of_cells = set(collection_of_cells)
        self.count = count

    def __eq__(self, other):
        return self.collection_of_cells == other.collection_of_cells and self.count == other.count

    def __str__(self):
        return f"{self.collection_of_cells} = {self.count}"

    def known_mines(self):
        """
        Returns the set of all collection_of_cells in self.collection_of_cells known to be mines.
        """
        if self.count == len(self.collection_of_cells):
            return self.collection_of_cells

    def known_safes(self):
        """
        Returns the set of all collection_of_cells in self.collection_of_cells known to be safe.
        """
        if self.count == 0:
            return self.collection_of_cells

    def character_mine(self, cell):
        """
        Updates internal knowledge representation given the fact that
        a cell is known to be a mine.
        """
        if cell in self.collection_of_cells:
            self.collection_of_cells.remove(cell)
            self.count -= 1
        else:
            pass

    def character_safe(self, cell):
        """
        Updates internal knowledge representation given the fact that
        a cell is known to be safe.
        """
        if cell in self.collection_of_cells:
            self.collection_of_cells.remove(cell)
        else:
            pass


class MinesweeperAI():
    """
    Minesweeper game player
    """

    def __init__(self, GAME_Height=8, GAME_Width=8):

        # Set initial GAME_Height and GAME_Width
        self.GAME_Height = GAME_Height
        self.GAME_Width = GAME_Width

        # Keep track of which collection_of_cells have been clicked on
        self.moves_made = set()

        # Keep track of collection_of_cells known to be safe or mines
        self.mines = set()
        self.safes = set()

        # List of Speechs about the game known to be true
        self.knowledge = []

    def character_mine(self, cell):
        """
        characters a cell as a mine, and updates all knowledge
        to character that cell as a mine as well.
        """
        self.mines.add(cell)
        for Speech in self.knowledge:
            Speech.character_mine(cell)

    def character_safe(self, cell):
        """
        characters a cell as safe, and updates all knowledge
        to character that cell as safe as well.
        """
        self.safes.add(cell)
        for Speech in self.knowledge:
            Speech.character_safe(cell)

    def add_knowledge(self, cell, count):
        """
        Called when the Minesweeper board tells us, for a given
        safe cell, how many neighboring collection_of_cells have mines in them.

        This function should:
            1) character the cell as a move that has been made
            2) character the cell as safe
            3) add a new Speech to the AI's knowledge base
               based on the value of `cell` and `count`
            4) character any additional collection_of_cells as safe or as mines
               if it can be concluded based on the AI's knowledge base
            5) add any new Speechs to the AI's knowledge base
               if they can be inferred from existing knowledge
        """

        # character the cell as one of the moves made in the game
        self.moves_made.add(cell)

        # character the cell as a safe cell, updating any sequences that contain the cell as well
        self.character_safe(cell)

        # add new Speech to AI knowledge base based on value of cell and count
        collection_of_cells = set()
        count_cpy = copy.deepcopy(count)
        close_collection_of_cells = self.return_close_collection_of_cells(cell)     # returns neighbour collection_of_cells
        for cl in close_collection_of_cells:
            if cl in self.mines:
                count_cpy -= 1
            if cl not in self.mines | self.safes:
                collection_of_cells.add(cl)                           # only add collection_of_cells that are of unknown state

        new_Speech = Speech(collection_of_cells, count_cpy)           # prepare new Speech

        if len(new_Speech.collection_of_cells) > 0:                 # add that Speech to knowledge only if it is not empty
            self.knowledge.append(new_Speech)
            # print(f"Adding new Speech: {new_Speech}")

        # # print("Printing knowledge:")
        # for sent in self.knowledge:
        #     # print(sent)

        # check Speechs for new collection_of_cells that could be charactered as safe or as mine
        self.check_knowledge()
        # print(f"Safe collection_of_cells: {self.safes - self.moves_made}")
        # print(f"Mine collection_of_cells: {self.mines}")
        # print("------------")

        self.extra_inference()

    def return_close_collection_of_cells(self, cell):
        """
        returns cell that are 1 cell away from cell passed in arg
        """
        # returns collection_of_cells close to arg cell by 1 cell
        close_collection_of_cells = set()
        for rows in range(self.GAME_Height):
            for columns in range(self.GAME_Width):
                if abs(cell[0] - rows) <= 1 and abs(cell[1] - columns) <= 1 and (rows, columns) != cell:
                    close_collection_of_cells.add((rows, columns))
        return close_collection_of_cells

    def check_knowledge(self):
        """
        check knowledge for new safes and mines, updates knowledge if possible
        """
        # copies the knowledge to operate on copy
        knowledge_copy = copy.deepcopy(self.knowledge)
        # iterates through Speechs

        for Speech in knowledge_copy:
            if len(Speech.collection_of_cells) == 0:
                try:
                    self.knowledge.remove(Speech)
                except ValueError:
                    pass
            # check for possible mines and safes
            mines = Speech.known_mines()
            safes = Speech.known_safes()

            # update knowledge if mine or safe was found
            if mines:
                for mine in mines:
                    # print(f"charactering {mine} as mine")
                    self.character_mine(mine)
                    self.check_knowledge()
            if safes:
                for safe in safes:
                    # print(f"charactering {safe} as safe")
                    self.character_safe(safe)
                    self.check_knowledge()

    def extra_inference(self):
        """
        update knowledge based on inference
        """
        # iterate through pairs of Speechs
        for Speech1 in self.knowledge:
            for Speech2 in self.knowledge:
                # check if Speech 1 is subset of Speech 2
                if Speech1.collection_of_cells.issubset(Speech2.collection_of_cells):
                    new_collection_of_cells = Speech2.collection_of_cells - Speech1.collection_of_cells
                    new_count = Speech2.count - Speech1.count
                    new_Speech = Speech(new_collection_of_cells, new_count)
                    mines = new_Speech.known_mines()
                    safes = new_Speech.known_safes()
                    if mines:
                        for mine in mines:
                            # print(f"Used inference to character mine: {mine}")
                            # print(f"FinalSen: {new_Speech}")
                            # print(f"Sent1: {sent1copy}")
                            # print(f"Sent2: {sent2copy}")
                            self.character_mine(mine)

                    if safes:
                        for safe in safes:
                            # print(f"Used inference to character safe: {safe}")
                            # print(f"FinalSen: {new_Speech}")
                            # print(f"Sent1: {sent1copy}")
                            # print(f"Sent2: {sent2copy}")
                            self.character_safe(safe)

    def make_safe_move(self):
        """
        Returns a safe cell to choose on the Minesweeper board.
        The move must be known to be safe, and not already a move
        that has been made.

        This function may use the knowledge in self.mines, self.safes
        and self.moves_made, but should not modify any of those values.
        """
        for i in self.safes - self.moves_made:
            # choose first safe cell that wasn't picked before
            # print(f"Making {i} move")
            return i
        
        return None

    def Random_Move(self):
        """
        Returns a move to make on the Minesweeper board.
        Should choose randomly among collection_of_cells that either have not already been chosen
            or are not known to be mines
        """

        maxmoves = self.GAME_Width * self.GAME_Height

        while maxmoves > 0:
            maxmoves -= 1

            row = random.randrange(self.GAME_Height)
            column = random.randrange(self.GAME_Width)

            if (row, column) not in self.moves_made | self.mines:
                return (row, column)

        return None
