import pygame
import sys
import time

from minesweeper import Minesweeper, MinesweeperAI

GAME_Height = 8
GAME_Width = 8
MINES = 8

# Colors
BLACK = (0, 0, 0)
GRAY = (180, 180, 180)
WHITE = (255, 255, 255)

# Create game
pygame.init()
GAME_Size = GAME_Width, GAME_Height = 600, 400
screen = pygame.display.set_mode(GAME_Size)

# Fonts
OPEN_SANS = "assets/fonts/OpenSans-Regular.ttf"
smallFont = pygame.font.Font(OPEN_SANS, 20)
mediumFont = pygame.font.Font(OPEN_SANS, 28)
largeFont = pygame.font.Font(OPEN_SANS, 40)

# Compute board GAME_Size
BOARD_PADDING = 20
board_GAME_Width = ((2 / 3) * GAME_Width) - (BOARD_PADDING * 2)
board_GAME_Height = GAME_Height - (BOARD_PADDING * 2)
cell_GAME_Size = int(min(board_GAME_Width / GAME_Width, board_GAME_Height / GAME_Height))
board_origin = (BOARD_PADDING, BOARD_PADDING)

# Add images
flag = pygame.image.load("assets/images/flag.png")
flag = pygame.transform.scale(flag, (cell_GAME_Size, cell_GAME_Size))
mine = pygame.image.load("assets/images/mine.png")
mine = pygame.transform.scale(mine, (cell_GAME_Size, cell_GAME_Size))

# Create game and AI agent
game = Minesweeper(GAME_Height=GAME_Height, GAME_Width=GAME_Width, mines=MINES)
ai = MinesweeperAI(GAME_Height=GAME_Height, GAME_Width=GAME_Width)

# Keep track of revealed cells, flagged cells, and if a mine was hit
revealed_cells = set()
flags_set = set()
GAME_Lost = False

# Show Show_instructions initially
Show_instructions = True

while True:

    # Check if game quit
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()

    screen.fill(BLACK)

    # Show game Show_instructions
    if Show_instructions:

        # Title
        title = largeFont.render("Play Minesweeper", True, WHITE)
        titleRect = title.get_rect()
        titleRect.center = ((GAME_Width / 2), 50)
        screen.blit(title, titleRect)

        # Rules
        rules = [
            "Click a cell to reveal it.",
            "Right-click a cell to mark it as a mine.",
            "Mark all mines successfully to win!"
        ]
        for i, rule in enumerate(rules):
            line = smallFont.render(rule, True, WHITE)
            lineRect = line.get_rect()
            lineRect.center = ((GAME_Width / 2), 150 + 30 * i)
            screen.blit(line, lineRect)

        # Play game button
        buttonRect = pygame.Rect((GAME_Width / 4), (3 / 4) * GAME_Height, GAME_Width / 2, 50)
        buttonText = mediumFont.render("Play Game", True, BLACK)
        buttonTextRect = buttonText.get_rect()
        buttonTextRect.center = buttonRect.center
        pygame.draw.rect(screen, WHITE, buttonRect)
        screen.blit(buttonText, buttonTextRect)

        # Check if play button clicked
        click, _, _ = pygame.mouse.get_pressed()
        if click == 1:
            mouse = pygame.mouse.get_pos()
            if buttonRect.collidepoint(mouse):
                Show_instructions = False
                time.sleep(0.3)

        pygame.display.flip()
        continue

    # Draw board
    cells = []
    for i in range(GAME_Height):
        row = []
        for j in range(GAME_Width):

            # Draw rectangle for cell
            rect = pygame.Rect(
                board_origin[0] + j * cell_GAME_Size,
                board_origin[1] + i * cell_GAME_Size,
                cell_GAME_Size, cell_GAME_Size
            )
            pygame.draw.rect(screen, GRAY, rect)
            pygame.draw.rect(screen, WHITE, rect, 3)

            # Add a mine, flag, or number if needed
            if game.is_mine((i, j)) and GAME_Lost:
                screen.blit(mine, rect)
            elif (i, j) in flags_set:
                screen.blit(flag, rect)
            elif (i, j) in revealed_cells:
                neighbors = smallFont.render(
                    str(game.nearby_mines((i, j))),
                    True, BLACK
                )
                neighborsTextRect = neighbors.get_rect()
                neighborsTextRect.center = rect.center
                screen.blit(neighbors, neighborsTextRect)

            row.append(rect)
        cells.append(row)

    # AI Move button
    aiButton = pygame.Rect(
        (2 / 3) * GAME_Width + BOARD_PADDING, (1 / 3) * GAME_Height - 50,
        (GAME_Width / 3) - BOARD_PADDING * 2, 50
    )
    buttonText = mediumFont.render("AI Move", True, BLACK)
    buttonRect = buttonText.get_rect()
    buttonRect.center = aiButton.center
    pygame.draw.rect(screen, WHITE, aiButton)
    screen.blit(buttonText, buttonRect)

    # Reset button
    resetButton = pygame.Rect(
        (2 / 3) * GAME_Width + BOARD_PADDING, (1 / 3) * GAME_Height + 20,
        (GAME_Width / 3) - BOARD_PADDING * 2, 50
    )
    buttonText = mediumFont.render("Reset", True, BLACK)
    buttonRect = buttonText.get_rect()
    buttonRect.center = resetButton.center
    pygame.draw.rect(screen, WHITE, resetButton)
    screen.blit(buttonText, buttonRect)

    # Display text
    text = "GAME_Lost" if GAME_Lost else "Won" if game.mines == flags_set else ""
    text = mediumFont.render(text, True, WHITE)
    textRect = text.get_rect()
    textRect.center = ((5 / 6) * GAME_Width, (2 / 3) * GAME_Height)
    screen.blit(text, textRect)

    move = None

    left, _, right = pygame.mouse.get_pressed()

    # Check for a right-click to toggle flagging
    if right == 1 and not GAME_Lost:
        mouse = pygame.mouse.get_pos()
        for i in range(GAME_Height):
            for j in range(GAME_Width):
                if cells[i][j].collidepoint(mouse) and (i, j) not in revealed_cells:
                    if (i, j) in flags_set:
                        flags_set.remove((i, j))
                    else:
                        flags_set.add((i, j))
                    time.sleep(0.2)

    elif left == 1:
        mouse = pygame.mouse.get_pos()

        # If AI button clicked, make an AI move
        if aiButton.collidepoint(mouse) and not GAME_Lost:
            move = ai.make_safe_move()
            if move is None:
                move = ai.make_random_move()
                if move is None:
                    flags_set = ai.mines.copy()
                    print("No moves left to make.")
                else:
                    print("No known safe moves, AI making random move.")
            else:
                print("AI making safe move.")
            time.sleep(0.2)

        # Reset game state
        elif resetButton.collidepoint(mouse):
            game = Minesweeper(GAME_Height=GAME_Height, GAME_Width=GAME_Width, mines=MINES)
            ai = MinesweeperAI(GAME_Height=GAME_Height, GAME_Width=GAME_Width)
            revealed_cells = set()
            flags_set = set()
            GAME_Lost = False
            continue

        # User-made move
        elif not GAME_Lost:
            for i in range(GAME_Height):
                for j in range(GAME_Width):
                    if (cells[i][j].collidepoint(mouse)
                            and (i, j) not in flags_set
                            and (i, j) not in revealed_cells):
                        move = (i, j)

    # Make move and update AI knowledge
    if move:
        if game.is_mine(move):
            GAME_Lost = True
        else:
            nearby = game.nearby_mines(move)
            revealed_cells.add(move)
            ai.add_knowledge(move, nearby)

    pygame.display.flip()
