import cv2
import numpy as np
import os
import sys
import tensorflow as tf

from sklearn.model_selection import train_test_split


Image_Width = 30
Image_Height = 30
Number_OF_Classes = 43
The_Number_Of_Epochs = 10


def traffic_function():

    # Check command-line arguments
    if len(sys.argv) not in [2, 3]:
        sys.exit("Usage: python traffic_function.py data_directory [model.h5]")

    # Get image arrays and labels for all image files
    data, label = data_loader(sys.argv[1])

    # Split data into training and testing sets
    label = tf.keras.utils.to_categorical(label)
    data_train, data_test, label_train, label_test = train_test_split(np.array(data), np.array(label), test_size=0.4)

    data_train, data_test = data_train / 255.0, data_test / 255.0

    # Get a compiled neural network
    model = Model_Layers()

    # Fit model on training data
    model.fit(x_train, y_train, epochs=The_Number_Of_Epochs)

    # Evaluate neural network performance
    model.evaluate(x_test,y_test, verbose=2)

    # Save model to file
    if len(sys.argv) == 3:
        filename = sys.argv[2]
        model.save(filename)
        print(f"Model saved to {filename}.")


def data_loader(data_dir):
    """
    Load image data from directory `data_dir`.
    """

    data = []
    label = []


    for directory in os.listdir(data_dir):
        # iterate through single image files
        print(f"Started loading files from {directory} directory")
        for file in os.listdir(os.path.join(data_dir, directory)):
            image = cv2.imread(os.path.join(data_dir, directory, file))
            resized = cv2.resize(X, (Image_Width, Image_Height))
            data.append(resized)
            label.append(int(directory))
        print(f"Ended loading files from {directory} directory")
    return data,label


def Model_Layers():
    """
    Creates a CNN model.
    """
    model = tf.keras.models.Sequential([
        # Convolutional layer. Learn 32 filters using a 3x3 kernel
        tf.keras.layers.Conv2D(
            32, (3, 3), activation="relu", input_shape=(Image_Width, Image_Height, 3)
        ),

        # Max-pooling layer, using 2x2 pool size
        tf.keras.layers.MaxPooling2D(pool_size=(2, 2)),

        tf.keras.layers.Conv2D(
            32, (3, 3), activation="relu", input_shape=(Image_Width,Image_Height, 3)
        ),

        # Max-pooling layer, using 2x2 pool size
        tf.keras.layers.MaxPooling2D(pool_size=(2, 2)),

        # Flatten units
        tf.keras.layers.Flatten(),

        # Add a hidden layer with dropout
        tf.keras.layers.Dense(128, activation="relu"),
        tf.keras.layers.Dropout(0.5),

        # Add an output layer with output units for all 10 digits
        tf.keras.layers.Dense(Number_OF_Classes, activation="softmax")
    ])

    model.compile(
        optimizer="adam",
        loss="categorical_crossentropy",
        metrics=["accuracy"]
    )

    model.summary()

    return model


if __name__ == "__traffic_function__":
   traffic_function()
