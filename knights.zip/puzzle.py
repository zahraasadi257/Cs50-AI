from logic import *

knight_A = Symbol("A is a Knight")
knave_A = Symbol("A is a Knave")

knight_B = Symbol("B is a Knight")
knave_B = Symbol("B is a Knave")

knight_C = Symbol("C is a Knight")
knave_C = Symbol("C is a Knave")

# Puzzle 0
# A says "I am both a knight and a knave."
knowledge0 = And(
    Not(And(knight_A, knave_A)),  # cannot be knight and knave at the same time
    Or(knight_A, knave_A),         # will be Knight or Knave
    Implication(knight_A, And(knight_A, knave_A)),
    Implication(knave_A, Not(And(knight_A, knave_A)))
)

# Puzzle 1
# A says "We are both knaves."
# B says nothing.
knowledge1 = And(
    Not(And(knight_A, knave_A)),  # cannot be knight and knave at the same time
    Or(knight_A, knave_A),        # will be Knight or Knave

    Not(And(knight_B, knave_B)),  # cannot be knight and knave at the same time
    Or(knight_B, knave_B),        # will be Knight or Knave

    # Or(And(knight_A, knave_B), And(knave_A, knight_B)), # A and B can't be the same figure

    Implication(knight_A, And(knave_A, knave_B)),
    Implication(knave_A, Not(And(knave_A, knave_B)))
)

# Puzzle 2
# A says "We are the same kind."
# B says "We are of different kinds."
knowledge2 = And(
    Not(And(knight_A, knave_A)),  # cannot be knight and knave at the same time
    Or(knight_A, knave_A),        # will be Knight or Knave

    Not(And(knight_B, knave_B)),  # cannot be knight and knave at the same time
    Or(knight_B, knave_B),        # will be Knight or Knave

    # Or(And(knight_A, knave_B), And(knave_A, knight_B)), # A and B can't be the same figure

    Implication(knight_A, And(knight_A, knight_B)),
    Implication(knave_A, Not(And(knave_A, knave_B))),

    Implication(knight_B, And(knight_B, knave_A)),
    Implication(knave_B, Not(And(knave_B, knight_A)))
)

# Puzzle 3
# A says either "I am a knight." or "I am a knave.", but you don't know which.
# B says "A said 'I am a knave'."
# B says "C is a knave."
# C says "A is a knight."
knowledge3 = And(
    Not(And(knight_A, knave_A)),  # A cannot be knight and knave at the same time
    Or(knight_A, knave_A),        # A will be Knight or Knave

    Not(And(knight_B, knave_B)),  # B cannot be knight and knave at the same time
    Or(knight_B, knave_B),        # B will be Knight or Knave

    Not(And(knight_C, knave_C)),  # C cannot be knight and knave at the same time
    Or(knight_C, knave_C),        # C will be Knight or Knave

    # A says either "I am a knight." or "I am a knave.", but you don't know which.
    Or(
        # "I am a knight."
        And(
            Implication(knight_A, knight_A),
            Implication(knave_A, Not(knight_A))
        ),
        
        # "I am a knave."
        And(
            Implication(knight_A, knave_A),
            Implication(knave_A, Not(knave_A))
        )
    ),

    Not(And(
        # "I am a knight."
        And(
            Implication(knight_A, knight_A),
            Implication(knave_A, Not(knight_A))
        ),
        
        # "I am a knave."
        And(
            Implication(knight_A, knave_A),
            Implication(knave_A, Not(knave_A))
        )
    )),

    # B says "A said 'I am a knave'."
    Implication(knight_B, And(
        Implication(knight_A, knave_A),
        Implication(knave_A, Not(knave_A))
    )),

    Implication(knave_B, Not(And(
        Implication(knight_A, knave_A),
        Implication(knave_A, Not(knave_A))
    ))),


    # B says "C is a knave."
    Implication(knight_B, knave_C),
    Implication(knave_B, Not(knave_C)),

    # C says "A is a knight."
    Implication(knight_C, knight_A),
    Implication(knave_C, Not(knight_A))
)


def main():
    symbols = [knight_A, knave_A, knight_B, knave_B, knight_C, knave_C]
    collection_of_puzzles = [
        ("Puzzle 0", knowledge0),
        ("Puzzle 1", knowledge1),
        ("Puzzle 2", knowledge2),
        ("Puzzle 3", knowledge3)
    ]
    for puzzle, knowledge in collection_of_puzzles:
        print(puzzle)
        if len(knowledge.conjuncts) == 0:
            print("    Not yet implemented.")
        else:
            for symbol in symbols:
                if model_check(knowledge, symbol):
                    print(f"    {symbol}")


if __name__ == "__main__":
    main()
