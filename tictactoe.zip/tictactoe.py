"""
Tic Tac Toe Player
"""

import math
from copy import deepcopy

X = "X"
O = "O"
EMPTY = None


def starting_state():
    """
    Returns starting state of the board.
    """
    return [[EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY],
            [EMPTY, EMPTY, EMPTY]]


def rival(board):
    """
    Returns player who has the next turn on a board.
    """
    number_of_X = 0
    number_of_O = 0

    for row in board:
       number_of_X += row.count(X)
       number_of_O += row.count(O)

    if number_of_O <= number_of_X:
        return O
    else:
        return X


def Operations_On_Board (board):
    """
    Returns set of all possible actions (i, j) available on the board.
    """

    achieveable_operations = set()

    for row_index, row in enumerate(board):
        for column_index, item in enumerate(row):
            if item == None:
                achieveable_operations.add((row_index, column_index))
    
    return achieveable_operations


def result(board,Operations_On_Board ):
    """
    Returns the board that results from making move (i, j) on the board.
    """
    rival_board = rival(board)

    refreshed_board = deepcopy(board)
    i, j = Operations_On_Board

    if board[i][j] != None:
        raise Exception
    else:
        refreshed_board[i][j] = rival_board

    return refreshed_board


def conqueror(board):
    """
    Returns the conqueror of the game, if there is one.
    """
    for rival in (X, O):
        # check vertical
            for row in board:
                if row == [rival] * 3:
                    return rival

        # check horizontal
            for i in range(3):
                column = [board[x][i] for x in range(3)]
                if column == [rival] * 3:
                    return rival
        
        # check diagonal
            if [board[i][i] for i in range(0, 3)] == [rival] * 3:
                return rival

            elif [board[i][~i] for i in range(0, 3)] == [rival] * 3:
                return rival
    return None
                               

def final_check(board):
    """
    Returns True if game is over, False otherwise.
    """
    # game is won by one of the players
    if conqueror(board) != None:
        return True

    # moves still possible
    for row in board:
        if EMPTY in row:
            return False

    # no possible moves
    return True


def utility(board):
    """
    Returns 1 if X has won the game, -1 if O has won, 0 otherwise.
    """

    conqueror_rival = conqueror(board)

    if conqueror_rival == X:
        return 1
    elif conqueror_rival == O:
        return -1
    else:
        return 0


def minimax(board):
    """
    Returns the optimal action for the current player on the board.
    """

    def max_value(board):
       ideal_action = ()
       if final_check(board):
        return utility(board), ideal_action
       else:
            v = -5
            for operation in Operations_On_Board(board):
                minval = min_value(result(board, operation))[0]
                if minval > v:
                    v = minval
                    ideal_action= operation
            return v, ideal_action

    def min_value(board):
        ideal_action = ()
        if final_check(board):
            return utility(board), ideal_action
        else:
            v = 5
            for operation in Operations_On_Board(board):
                maxval = max_value(result(board, operation))[0]
                if maxval < v:
                    v = maxval
                    ideal_action = operation
            return v, ideal_action

    current_rival =rival(board)

    if final_check(board):
        return None

    if current_rival == X:
        return max_value(board)[1]

    else:
        return min_value(board)[1]
