import os
import sys
import random
import re


DAMPING_FACTOR = 0.85
NUM_SAMPLES= 10000

def PAGE_RANK():
    if len(sys.argv) != 2:
        sys.exit("Usage: python pagerank.py web_collection")
    web_collection = Gather_Links(sys.argv[1])
    ranks = sample_PAGE_RANK(web_collection, DAMPING_FACTOR, NUM_SAMPLES)
    print(f" Results from Sampling function (n = {NUM_SAMPLES})")
    for page in sorted(ranks):
        print(f"  {page}: {ranks[page]:.4f}")
    ranks = iterate_PAGE_RANK(web_collection, DAMPING_FACTOR)
    print(f" Results from Iteration function")
    for page in sorted(ranks):
        print(f"  {page}: {ranks[page]:.4f}")

"""
    Parse a directory contains HTML pages and control if  there are links to other pages or not.
   This function's output  is a dictionary where each key is a page, and values are
     linked pages to  this page.
    """
def Gather_Links(directory):

    pages = {}

    # Read the dataset and extract  links from HTML files
    for filename in os.listdir(directory):
        if not filename.endswith(".html"):
            continue
        with open(os.path.join(directory, filename)) as f:
            contents = f.read()
            links = re.findall(r"<a\s+(?:[^>]*?)href=\"([^\"]*)\"", contents)
            pages[filename] = set(links) - {filename}

    # Only include links to other pages in the corpus
    for filename in pages:
        pages[filename] = set(
            link for link in pages[filename]
            if link in pages
        )

    return pages

"""
    Return P(current page | next page)


    With probability `damping_factor`, choose a link at random
    linked to by `page`. With probability `1 - damping_factor`, choose
    a link at random chosen from all pages in the web_collection.
    """
def transition_model(web_collection, page, damping_factor):

   transition_distribution = {}

    # check if page has outgoing links
    Dic_len = len(web_collection.keys())
    Pages_len = len(web_collection[page])

    if  Pages_len < 1:
        # no outgoing pages, choosing randomly from all possible pages
        for key in web_collection.keys():
           transition_distribution[key] = 1 / Dic_len

    else:
        # there are outgoing pages, calculating distribution
        random_factor = (1 - damping_factor) / Dic_len
        even_factor = damping_factor / Pages_len

        for key in web_collection.keys():
            if key not in web_collection[page]:
               transition_distribution[key] = random_factor
            else:
               transition_distribution[key] = even_factor + random_factor

    returntransition_distribution


def sample_PAGE_RANK(web_collection, damping_factor, n):
    """
    Return PAGE_RANK values for each page by sampling `n` pages
    according to transition model, starting with a page at random.

    Return a dictionary where keys are page names, and values are
    their estimated PAGE_RANK value (a value between 0 and 1). All
    PAGE_RANK values should sum to 1.
    """

    # prepare dictionary with number of samples == 0
    samples_dict = web_collection.copy()
    for i in samples_dict:
        samples_dict[i] = 0
    sample = None
 # itearting n times
    for _ in range(n):
        if sample:
            # previous sample is available, choosing using transition model
            dist = transition_model(web_collection,sample, damping_factor)
            dist_lst = list(dist.keys())
            dist_weights = [dist[i] for i in dist]
            sample = random.choices(dist_lst, dist_weights, k=1)[0]
        else:
            # no previous sample, choosing randomly
            sample = random.choice(list(web_collection.keys()))

        # count each sample
        instance_dictionary[sample] += 1

    # turn sample count to percentage
    for item in samples_dict:
        instanc[item] /= n

    return samples_dict


def iterate_PAGE_RANK(web_collection, damping_factor):
    """
    Return PAGE_RANK values for each page by iteratively updating
    PAGE_RANK values until convergence.

    Return a dictionary where keys are page names, and values are
    their estimated PAGE_RANK value (a value between 0 and 1). All
    PAGE_RANK values should sum to 1.
    """

    previous_dictionary = {}
    next_dictinoary = {}
    # length is the number of pages in the web_collection
    length = len(web_collection)
    # assigning each page a rank of 1/n, where n is total number of pages in the corpus
    for page in web_collection:
        previous_dictionary[page] = 1 / length

    # repeatedly calculating new rank values basing on all of the current rank values
    while True:
        for page in web_collection:
            temp = 0
            for linking_page in web_collection:
                # check if page links to our page
                if page in web_collection[linking_page]:
                    temp += (previous_dictionary[linking_page] / len(web_collection[linking_page]))
                # if page has no links, interpret it as having one link for every other page
                if len(web_collection[linking_page]) == 0:
                    temp += (previous_dictionary[linking_page]) / len(web_collection)
            temp *= damping_factor
            temp += (1 - damping_factor) / length

            next_dictinoary[page] = temp

        competition = max([abs(next_dictinoary[x] - previous_dictionary[x]) for x in previous_dictionary])
        if competition < 0.001:
            break
        else:
            previous_dictionary = next_dictinoary.copy()

    return previous_dictionary

if __name__ == "__PAGE_RANK__":
    PAGE_RANK()
