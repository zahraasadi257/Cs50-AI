
###Importing required packages
import csv
import pandas as pd
import sys

from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import confusion_matrix




def shopping_function():

    # Control command-line arguments
    if len(sys.argv) != 2:
        sys.exit("Usage: python shopping_function.py data")

    # Load data from spreadsheet and split into train and test sets
    X, Y = data_loader(sys.argv[1])
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.4)

    # Train model and make predictions
    model = train_model(X_train, y_train)
    Y_pred = model.predict(X_test)
    TPR, TNR = evaluate(y_test,Y_pred)

    # Print results
    print(f"Correct: {(y_test == Y_pred).sum()}")
    print(f"Incorrect: {(y_test != Y_pred).sum()}")
    print(f"TPR: {100 * TPR:.2f}%")
    print(f"TNR: {100 * TNR:.2f}%")


def data_loader(filename):
    """
    Load dataset and convert it to a list of labels as Y_list and list of documents as X_list

    """

    X = []
    Y = []

    months = {'Jan': 0,
              'Feb': 1,
              'Mar': 2,
              'Apr': 3,
              'May': 4,
              'June': 5,
              'Jul': 6,
              'Aug': 7,
              'Sep': 8,
              'Oct': 9,
              'Nov': 10,
              'Dec': 11}

    # read csv file
    dataset = pd.read_csv(filename)

    # prepare labels dataframe
    Y_l = dataset['Income']

    # creating X
    X_l = dataset.drop(columns=['Income'])

    # replace month names with numbers
    X_l = X_l.replace(months)

    # replace boolean with 0/1 values
    X_l['VisitorType'] = X_l['VisitorType'].apply(lambda x: 1 if x == 'Returning_Visitor' else 0)
    X_l['Weekend'] = X_l['Weekend'].apply(lambda x: 1 if x == 'True' else 0)
    Y_l = Y_l.apply(lambda x: 1 if x is True else 0)

    # convert dataframes to lists
    X_list = X_l.values.tolist()
    Y_list = Y_l.values.tolist()

    return X_list, Y_list


def train_model(X,Y):
    """
    Fit k_nearest neighbors to X, Y
    """

    neighbor = KNeighborsClassifier(n_neighbors=1)
    neighbor.fit(X,Y)
    return neighbor


def evaluate(Y, Y_pred):
    """
    Compare actual labels of test data to predict labels for it and calculate TPR and
     TNR
    """
    tn, fp, fn, tp = confusion_matrix(Y, Y_pred).ravel()
    TPR = tp / (tp + fn)
    TNR = tn / (tn + fp)

    return TPR, TNR


if __name__ == "__shopping_function__":
    shopping_function()
