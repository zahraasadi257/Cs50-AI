
###Import required libraries
import math
import sys
import os
import string
import nltk

FILE_MATCHES = 1
SENTENCE_MATCHES = 1


def answer_questions():
    # Check command-line arguments
    if len(sys.argv) != 2:
        sys.exit("Usage: python questions.py corpus_directory")

    # Calculate IDF values across files
    files = load_text_files(sys.argv[1])
    file_word_lists = {
        file_name: tokenize_text(files[file_name])
        for file_name in files
    }
    inverse_document_frequencies = compute_inverse_document_frequencies(file_word_lists)

    # Prompt user for a query
    query = set(tokenize_input("Query: "))

    # Determine the top file matches according to TF-IDF
    top_file_names = top_matching_files(query, file_word_lists, inverse_document_frequencies, n=FILE_MATCHES)

    # Extract sentences from the top files
    sentences = extract_sentences_from_files(top_file_names, files)

    # Compute IDF values across sentences
    sentence_idfs = compute_inverse_document_frequencies(sentences)

    # Determine the top sentence matches
    top_matches = top_matching_sentences(query, sentences, sentence_idfs, n=SENTENCE_MATCHES)
    for match in top_matches:
        print(match)


def load_text_files(directory):
    """
    Return a dictionary mapping the filename of each `.txt` file inside that directory
    to the file's contents as a string.
    """
    file_contents = {}

    for file in os.listdir(directory):
        with open(os.path.join(directory, file), encoding="utf-8") as text_file:
            file_contents[file] = text_file.read()

    return file_contents


def tokenize_text(document):
    """
    Return a list of all the lowercased words in the document, excluding punctuation and stopwords.
    """
    tokenized = nltk.tokenize.word_tokenize(document.lower())
    final_word_list = [word for word in tokenized if
                       word not in string.punctuation and word not in nltk.corpus.stopwords.words("english")]
    return final_word_list


def compute_inverse_document_frequencies(documents):
    """
    Return a dictionary that maps words to their IDF values.
    """
    idf_values = {}
    total_document_count = len(documents)
    unique_words = set(sum(documents.values(), []))

    for word in unique_words:
        word_appearance_count = 0
        for doc in documents.values():
            if word in doc:
                word_appearance_count += 1

        idf_values[word] = math.log(total_document_count / word_appearance_count)

    return idf_values


def top_matching_files(query, files, idfs, n):
    """
    Return a list of the filenames of the top `n` files that match the query, ranked according to tf-idf.
    """
    file_scores = {}

    for file_name, file_content in files.items():
        file_score = 0
        for word in query:
            if word in file_content:
                file_score += file_content.count(word) * idfs[word]
        if file_score != 0:
            file_scores[file_name] = file_score

    sorted_files = [file for file, score in sorted(file_scores.items(), key=lambda x: x[1], reverse=True)]
    return sorted_files[:n]


def top_matching_sentences(query, sentences, idfs, n):
    """
    Return a list of the top `n` sentences that match the query, ranked according to idf.
    """
    sentence_scores = {}

    for sentence, words in sentences.items():
        score = 0
        for word in query:
            if word in words:
                score += idfs[word]

        if score != 0:
            word_density = sum([words.count(w) for w in query]) / len(words)
            sentence_scores[sentence] = (score, word_density)

    sorted_sentences = [sentence for sentence, scores in
                        sorted(sentence_scores.items(), key=lambda x: (x[1][0], x[1][1]), reverse=True)]
    return sorted_sentences[:n]


if __name__ == "__main__":
    answer_questions()