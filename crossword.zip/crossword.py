class CrosswordVariable():

    HORIZONTAL = "HORIZONTAL"
    VERTICAL = "VERTICAL"

    """Produce a  CrosswordVariable with starting points coordination, direction, and length."""
    def __init__(self,row ,col , direction, length):
        self.row =row
        self.col = col
        self.direction = direction
        self.length = length
        self.cells = list()
        for k in range(self.length):
            self.cells.append(
                (self.row + (k if self.direction == CrosswordVariable.VERTICAL else 0),
                 self.col + (k if self.direction == CrosswordVariable.HORIZONTAL else 0))
            )

    def __hash__(self):
        return hash((self.row, self.col, self.direction, self.length))

    def __eq__(self, other):
        return (
            (self.row == other.row) and
            (self.col == other.col) and
            (self.direction == other.direction) and
            (self.length == other.length)
        )

    def __str__(self):
        return f"({self.row}, {self.col}) {self.direction} : {self.length}"

    def __repr__(self):
        direction = repr(self.direction)
        return f"CrosswordVariable({self.row}, {self.col}, {direction}, {self.length})"


class Crossword_Puzzle():

    def __init__(self, construction_file, words_file):

        # Define the construction of crossword
        with open(construction_file) as f:
            contents = f.read().splitlines()
            self.height = len(contents)
            self.width = max(len(line) for line in contents)

            self.construction = []
            for row in range(self.height):
                row = []
                for col in range(self.width):
                    if col >= len(contents[row]):
                        row.append(False)
                    elif contents[row][col] == "_":
                        row.append(True)
                    else:
                        row.append(False)
                self.construction.append(row)

        # Save vocabulary list
        with open(words_file) as f:
            self.words = set(f.read().upper().splitlines())

        # Determine CrosswordVariable set
        self.CrosswordVariables = set()
        for row in range(self.height):
            for col in range(self.width):

                # Vertical words
                starts_word = (
                    self.construction[row][col]
                    and (row == 0 or not self.construction[row - 1][col])
                )
                if starts_word:
                    length = 1
                    for k in range(row + 1, self.height):
                        if self.construction[k][col]:
                            length += 1
                        else:
                            break
                    if length > 1:
                        self.CrosswordVariables.add(CrosswordVariable(
                           row=row, col=col,
                            direction=CrosswordVariable.VERTICAL,
                            length=length
                        ))

                # Horizontal words
                starts_word = (
                    self.construction[row][col]
                    and (col == 0 or not self.construction[row][col - 1])
                )
                if starts_word:
                    length = 1
                    for k in range(col + 1, self.width):
                        if self.construction[row][k]:
                            length += 1
                        else:
                            break
                    if length > 1:
                        self.CrosswordVariables.add(CrosswordVariable(
                           row=row, col=col,
                            direction=CrosswordVariable.HORIZONTAL,
                            length=length
                        ))

        # Compute common part for each word
        # For any pair of CrosswordVariables v1, v2, their common part is  None, if the two CrosswordVariables do not have anything in common; or
        #    (row, col), where v1'srowth character overlaps v2's colth character
        self.commons = dict()
        for v1 in self.CrosswordVariables:
            for v2 in self.CrosswordVariables:
                if v1 == v2:
                    continue
                cells1 = v1.cells
                cells2 = v2.cells
                intersection = set(cells1).intersection(cells2)
                if not intersection:
                    self.commons[v1, v2] = None
                else:
                    intersection = intersection.pop()
                    self.commons[v1, v2] = (
                        cells1.index(intersection),
                        cells2.index(intersection)
                    )

    """A CrosswordVariable as an input, set of common CrosswordVariables as outputs."""
    def neighbors(self, var):
        return set(
            v for v in self.CrosswordVariables
            if v != var and self.commons[v, var]
        )
