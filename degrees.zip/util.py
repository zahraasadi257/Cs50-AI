class Bulge():
    def __init__(self, operation, step, parent):
        self.operation = operation
        self.step = step
        self.parent = parent



class My_Stack_Frontier():
    def __init__(self):
        self.frontier = []

    def add(self, bulge):
        self.frontier.append(bulge)

    def holds_steps(self, state):
        return any(bulge.step == step for bulge in self.frontier)

    def blank(self):
        return len(self.frontier) == 0

    def delete(self):
        if self.blank():
            raise Exception("blank frontier")
        else:
            bulge = self.frontier[-1]
            self.frontier = self.frontier[:-1]
            return bulge


class My_Queue_Frontier(My_Stack_Frontier):

    def delete(self):
        if self.empty():
            raise Exception("blank frontier")
        else:
            bulge = self.frontier[0]
            self.frontier = self.frontier[1:]
            return bulge
