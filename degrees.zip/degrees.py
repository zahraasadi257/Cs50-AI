import csv
import sys

from util import Bulge, My_Stack_Frontier, My_Queue_Frontier

Movies = {}
People = {}
Names = {}

def data_loader(directory):
    """
     loading  all datasets
    """
    with open(f"{directory}/people.csv", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            People[row["id"]] = {
                "name": row["name"],
                "birth": row["birth"],
                "movies": set()
            }
            if row["name"].lower() not in Names:
                Names[row["name"].lower()] = {row["id"]}
            else:
                Names[row["name"].lower()].add(row["id"])



    with open(f"{directory}/movies.csv", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            Movies[row["id"]] = {
                "title": row["title"],
                "year": row["year"],
                "stars": set()
            }

    with open(f"{directory}/stars.csv", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                People[row["People_id"]]["movies"].add(row["movie_id"])
                Movies[row["movie_id"]]["stars"].add(row["People_id"])
            except KeyError:
                pass


def main():
    if len(sys.argv) > 2:
        sys.exit("Usage: python degrees.py [directory]")
    directory = sys.argv[1] if len(sys.argv) == 2 else "large"

    print("Data is loading ")
    data_loader(directory)
    print("Data loaded.")

    origin= People_id_for_name(input("Enter name: "))
    if origin is None:
        sys.exit("The People you are looking for did not found.")
    destination = People_id_for_name(input("Enter Name: "))
    if destination is None:
        sys.exit("The People you are looking for did not found.")

    path = The_shortest_path(origin,destination)

    if path is None:
        print("There is no path.")
    else:
        degrees = len(path)
        print(f"{degrees} is separation degrees.")
        path = [(None,origin)] + path
        for i in range(degrees):
            People1 = People[path[i][1]]["name"]
            People2 = People[path[i + 1][1]]["name"]
            movie = Movies[path[i + 1][0]]["title"]
            print(f"{i + 1}: {People1} and {People2} played in {movie}")


def The_shortest_path(origin, destination):
    observed = set()
    start = Bulge(step=origin, parent=None, operation=None)
    frontier = My_Queue_Frontier()
    frontier.add(start)

    while True:
        if frontier.empty():
            return None

        bulge = frontier.remove()

        if bulge.step == destination:
            rt = []

            while bulge.parent is not None:
                rt.append((bulge.operation, bulge.step))
                bulge = bulge.parent

            rt.reverse()
            return rt

        observed.add(bulge.step)

        neighbours = neighbors_for_people(bulge.step)

        for operation, step in neighbours:
            if not frontier.holds_steps(step) and step not in observed:
                child = Bulge(step=step, parent=bulge, operation=operation)
                if child.step == destination:
                    mem = []

                    while child.parent is not None:
                        mem.append((child.operation, child.step))
                        child = child.parent

                    mem.reverse()
                    return mem
                frontier.add(child)


def People_id_for_name(name):
    People_ids = list(tis.get(name.lower(), set()))
    if len(People_ids) == 0:
        return None
    elif len(People_ids) > 1:
        print(f"Which '{name}'?")
        for People_id in People_ids:
            People_id = People[People_id]
            name = People["name"]
            birth = People["birth"]
            print(f"ID: {People_id}, Name: {name}, Birth: {birth}")
        try:
            People_id = input("Enter planned People ID: ")
            if People_id in People_ids:
                return People_id
        except ValueError:
            pass
        return None
    else:
        return People_ids[0]


def neighbors_for_People(People_id):
    movie_ids = People[People_id]["movies"]
    neighbors = set()
    for movie_id in movie_ids:
        for People_id in People[movie_id]["stars"]:
            neighbors.add((movie_id, People_id))
    return neighbors


if __name__ == "__main__":
    main()
